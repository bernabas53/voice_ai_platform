import { useState, useEffect } from 'react'
import { FrappeProvider } from 'frappe-react-sdk'
import './App.css'

// Global variables from Vite config
declare global {
  const __APP_VERSION__: string
  const __BUILD_TIME__: string
}

// Types
interface VoiceMessage {
  id: string
  text: string
  timestamp: Date
  isUser: boolean
}

interface AppState {
  messages: VoiceMessage[]
  isListening: boolean
  isProcessing: boolean
  error: string | null
}

function App() {
  const [state, setState] = useState<AppState>({
    messages: [],
    isListening: false,
    isProcessing: false,
    error: null
  })

  const addMessage = (text: string, isUser: boolean = false) => {
    const newMessage: VoiceMessage = {
      id: Date.now().toString(),
      text,
      timestamp: new Date(),
      isUser
    }
    setState(prev => ({
      ...prev,
      messages: [...prev.messages, newMessage]
    }))
  }

  const handleVoiceInput = async () => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setState(prev => ({ ...prev, error: 'Voice input not supported in this browser' }))
      return
    }

    setState(prev => ({ ...prev, isListening: true, error: null }))

    try {
      // TODO: Implement actual voice recognition
      // This is a placeholder for voice input functionality
      addMessage('Voice input detected', true)

      // Simulate AI response
      setTimeout(() => {
        addMessage('I heard your voice input. This is a sample response from the AI.', false)
        setState(prev => ({ ...prev, isListening: false }))
      }, 2000)

    } catch (error) {
      setState(prev => ({
        ...prev,
        error: 'Failed to access microphone',
        isListening: false
      }))
    }
  }

  const clearMessages = () => {
    setState(prev => ({ ...prev, messages: [] }))
  }

  useEffect(() => {
    // Initialize with welcome message
    addMessage('Hello! I\'m your voice AI assistant. Click the microphone to start speaking.', false)
  }, [])

  return (
    <div className="App">
      <FrappeProvider>
        <div className="voice-ai-container">
          <header className="app-header">
            <h1>Voice AI Platform</h1>
            <p>Powered by Frappe & React</p>
          </header>

          <main className="main-content">
            <div className="messages-container">
              {state.messages.map((message) => (
                <div
                  key={message.id}
                  className={`message ${message.isUser ? 'user-message' : 'ai-message'}`}
                >
                  <div className="message-content">
                    {message.text}
                  </div>
                  <div className="message-timestamp">
                    {message.timestamp.toLocaleTimeString()}
                  </div>
                </div>
              ))}

              {state.isListening && (
                <div className="listening-indicator">
                  <div className="pulse"></div>
                  Listening...
                </div>
              )}

              {state.error && (
                <div className="error-message">
                  {state.error}
                </div>
              )}
            </div>

            <div className="controls">
              <button
                className={`voice-button ${state.isListening ? 'listening' : ''}`}
                onClick={handleVoiceInput}
                disabled={state.isListening || state.isProcessing}
              >
                <span className="mic-icon">🎤</span>
                {state.isListening ? 'Listening...' : 'Start Voice Input'}
              </button>

              <button
                className="clear-button"
                onClick={clearMessages}
                disabled={state.messages.length === 0}
              >
                Clear Messages
              </button>
            </div>
          </main>

          <footer className="app-footer">
            <p>Version {__APP_VERSION__} | Built on {new Date(__BUILD_TIME__).toLocaleDateString()}</p>
          </footer>
        </div>
      </FrappeProvider>
    </div>
  )
}

export default App
