// Test setup for Vitest

// Mock global variables from Vite config
(globalThis as any).__APP_VERSION__ = '1.0.0'
;(globalThis as any).__BUILD_TIME__ = new Date().toISOString()

// Mock browser APIs
Object.defineProperty(navigator, 'mediaDevices', {
  value: {
    getUserMedia: () => Promise.resolve({} as MediaStream),
  },
  writable: true,
})
